export type CreateUserParams = {
  email: string;
  password: string;
  role?: number;
};
export type UpdateUserParams = {
  email: string;
  password: string;
  role?: number;
};
