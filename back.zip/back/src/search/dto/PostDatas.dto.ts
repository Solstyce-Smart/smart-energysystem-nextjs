export class PostDatasDto {
  ewonId: string;
  tagName: string;
  lastSynchroDate: string;
  dateReq: Date;
  value: number;
  quality: string;
}
